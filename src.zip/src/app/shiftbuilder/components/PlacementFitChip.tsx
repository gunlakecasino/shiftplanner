"use client";

import React from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  fitVerdictLabel,
  fitVerdictStyles,
} from "@/lib/shiftbuilder/placementPadInsightSchema";
import type { PrerenderedPlacementFit } from "./placementFitScore";
import type { XaiFit } from "@/lib/shiftbuilder/placementPadInsightSchema";
import { premiumSpring } from "@/lib/premiumSpring";

export function isCriticalRepeatFit(
  fit?: PrerenderedPlacementFit | null,
): boolean {
  return fit?.fitVerdict === "critical_repeat";
}

export type PlacementFitChipProps = {
  /** Same prerender the placement pad instant block uses. */
  fit?: PrerenderedPlacementFit | null;
  /** Optional xAI override from PlacementPad (magic headline + verdict) for powerful deliberate insight surface in corner (per xAI full incorporation). Shows "xAI" badge + uses xAI verdict/summary when present. */
  xaiFit?: XaiFit;
  /** Use more compact sizing (for card headers) */
  compact?: boolean;
};

/** Screen-only rotation fit glance — excluded from print via `no-print`. */
export function PlacementFitChip({ fit, xaiFit, compact = false }: PlacementFitChipProps) {
  if (!fit && !xaiFit) return null;

  // Prefer xAI override for powerful deliberate insight in corner (magic one line surface)
  const effectiveVerdict = (xaiFit?.fitVerdict as any) || fit?.fitVerdict || "open_gap";
  const effectiveSummary = xaiFit?.fitSummary || fit?.fitSummary || "";
  const effectiveFact = fit?.fitFactLine || "";
  const isXai = !!xaiFit;

  const styles = fitVerdictStyles(effectiveVerdict);
  const label = fitVerdictLabel(effectiveVerdict);
  const title = isXai
    ? (xaiFit?.headline ? `${xaiFit.headline}\n${effectiveSummary}\n(xAI reasoned from board/week context + your Gold examples where relevant)` : effectiveSummary)
    : (effectiveFact ? `${effectiveSummary}\n${effectiveFact}` : effectiveSummary);

  const displayText = isXai
    ? (xaiFit?.headline ? xaiFit.headline.slice(0, 20) + (xaiFit.headline.length > 20 ? "…" : "") : "xAI")
    : label;

  const isFitVerdict = [
    "strong_fit",
    "acceptable",
    "questionable",
    "critical_repeat",
    "poor_fit",
    "needs_swap",
  ].includes(effectiveVerdict);

  // Card rotation-health glance: color-only dot (verdict label stays in tooltip).
  if (!isXai && isFitVerdict) {
    const dotBg = styles.bg || "#6B7280";
    const dotSize = compact ? 10 : 11;

    return (
      <AnimatePresence>
        <motion.span
          key={effectiveVerdict}
          className="sb-fit-dot no-print inline-flex flex-shrink-0 items-center justify-center"
          role="img"
          aria-label={`Rotation fit: ${label}`}
          style={{
            width: dotSize,
            height: dotSize,
            background: dotBg,
            boxShadow: "0 1px 2px rgba(0, 0, 0, 0.22), inset 0 0 0 1px rgba(255, 255, 255, 0.35)",
            borderRadius: "50%",
          }}
          title={title}
          onClick={(e) => e.stopPropagation()}
          onPointerDown={(e) => e.stopPropagation()}
          initial={{ opacity: 0, scale: 0.6 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.75 }}
          transition={premiumSpring}
        />
      </AnimatePresence>
    );
  }

  if (compact && !isXai) {
    return null;
  }

  const chipClass = isXai 
    ? "sb-fit-chip no-print inline-flex max-w-[118px] items-center justify-center rounded-full px-1 py-px text-[8px] font-semibold tracking-wide whitespace-nowrap leading-none" 
    : "inline-flex items-center px-1.5 py-[2px] rounded-full text-[9.5px] font-semibold tracking-wide whitespace-nowrap leading-none";

  return (
    <AnimatePresence>
      <motion.span
        key={isXai ? "xai" : effectiveVerdict}
        className={chipClass}
        style={{
          background: styles.bg,
          color: styles.text,
          border: `1px solid ${styles.border}`,
          fontFamily: "var(--font-atkinson, var(--font-ui, system-ui))",
        }}
        title={title + (isXai ? "  ·  xAI insight loaded in builder; hidden in print-preview/PDF" : "")}
        onClick={(e) => e.stopPropagation()}
        onPointerDown={(e) => e.stopPropagation()}
        initial={{ opacity: 0, scale: 0.8, y: 1 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.85 }}
        transition={premiumSpring}
      >
        {isXai && <span className="opacity-60 mr-px" style={{ fontSize: "6.5px", letterSpacing: "0" }}>✧</span>}
        {displayText}
      </motion.span>
    </AnimatePresence>
  );
}