

import { z } from "zod";

// …

export const GrokActionSchema = z.object({
  type: z.enum(["assign", "swap", "remove", "note"]),
  slotKey: z.string().optional(),
  tmId: z.string().optional(),
  fromSlot: z.string().optional(),
  toSlot: z.string().optional(),
  reason: z.string().min(1),
});

export const GrokStructuredResponseSchema = z.object({
  explanation: z.string(),
  actions: z.array(GrokActionSchema),
});

export type GrokStructuredResponse = z.infer<typeof GrokStructuredResponseSchema>;
export type GrokAction = z.infer<typeof GrokActionSchema>;

// …

export const GrokEnginePickSchema = z.object({
  slotKey: z.string().min(1),
  tmId: z.string().min(1),
  reason: z.string().min(1),
});

export const GrokEngineResponseSchema = z.object({
  explanation: z.string(),
  picks: z.array(GrokEnginePickSchema),
});

export type GrokEngineResponse = z.infer<typeof GrokEngineResponseSchema>;
export type GrokEnginePick = z.infer<typeof GrokEnginePickSchema>;

// …

export function safeParseStructuredResponse(raw: unknown) {
  return GrokStructuredResponseSchema.safeParse(raw);
}

export function safeParseEngineResponse(raw: unknown) {
  return GrokEngineResponseSchema.safeParse(raw);
}