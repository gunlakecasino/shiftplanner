

import { scoreAssignment, buildDefaultAdjacency, type ScoringContext } from "./scoring";

// Minimal interface to avoid circular imports
export interface AuxDef {
  key: string;
  label: string;
  locations: string[];
}

// …

export const PLACEMENT_ORDER: readonly string[] = [
  // 1. Restrooms (Men’s + Women’s) — highest priority block
  "MRR1",
  "WRR1",
  "MRR6",
  "WRR6",
  "MRR7",
  "WRR7",
  "MRR8",
  "WRR8",
  "MRR10",
  "WRR10",

  // 2. Admin
  "ADM",

  // 3–12. Main Zones in required sequence
  "Z9",
  "Z1",
  "Z4",
  "Z5",
  "Z2",
  "Z3",
  "Z8",
  "Z10",
  "Z7",
  "Z6",

  // 13. Zone 9 Smoking Room — FIXED POSITION (never conditional)
  "Z9SR",

  // 14–15. Trash
  "TR1",
  "TR2",

  // 16+. Overflow / Support slots (SP1, SP2, SP3, ...) come after everything above
] as const;

export function getSlotsInPlacementOrder(auxDefs: AuxDef[] = []): string[] {
  const fixed = [...PLACEMENT_ORDER];

  // Any extra support/overflow slots the operator has added must come last
  const extraSupport = auxDefs
    .map((d) => d.key)
    .filter((key) => !fixed.includes(key));

  return [...fixed, ...extraSupport];
}

// …

export interface CoveragePlannerInput {
  orderedSlots: string[];
  assignments: Record<string, any>;
  roster: any[]; // full or filtered roster
  graveOnly?: boolean;
  // Future: constraints, break rules, etc.
}

export interface CoveragePlannerResult {
  proposedAssignments: Record<string, string>; // slotKey -> tmId
  unassignedPeople: any[];
  notes: string[];
  
  breakdown: Record<string, SlotRanking>;
}

export interface SlotRanking {
  topCandidates: Array<{
    tmId: string;
    tmName: string;
    total: number;
    breakdown: import("./scoring").SignalBreakdown;
    excluded?: boolean;
    excludeReason?: string;
  }>;
  
  pickedTmId: string | null;
  
  preserved: boolean;
}

export function runCoveragePlanner(input: CoveragePlannerInput): CoveragePlannerResult {
  const { orderedSlots, assignments, roster } = input;

  const proposedAssignments: Record<string, string> = {};
  const assignedTmIds = new Set<string>();
  const notes: string[] = [];

  // TODO: Replace with real eligibility + scoring logic
  // For now: simple greedy assignment in strict order
  for (const slotKey of orderedSlots) {
    if (assignments[slotKey]?.tmId) {
      // Already assigned — respect existing
      proposedAssignments[slotKey] = assignments[slotKey].tmId;
      assignedTmIds.add(assignments[slotKey].tmId);
      continue;
    }

    // Find first eligible unassigned person (very basic for now)
    const candidate = roster.find(
      (tm: any) => !assignedTmIds.has(tm.id) && isEligibleForSlot(tm, slotKey)
    );

    if (candidate) {
      proposedAssignments[slotKey] = candidate.id;
      assignedTmIds.add(candidate.id);
    } else {
      notes.push(`No eligible candidate found for ${slotKey}`);
    }
  }

  const unassignedPeople = roster.filter((tm: any) => !assignedTmIds.has(tm.id));

  return {
    proposedAssignments,
    unassignedPeople,
    notes,
    breakdown: {},
  };
}

// …

export interface WeightedPlannerInput extends CoveragePlannerInput {
  
  scoringCtx: Omit<ScoringContext, "currentDraft" | "adjacency"> & {
    
    adjacency?: Map<string, string[]>;
  };
  
  topK?: number;
}

export function runWeightedPlanner(input: WeightedPlannerInput): CoveragePlannerResult {
  const { orderedSlots, assignments, roster, scoringCtx, topK = 5 } = input;

  const proposedAssignments: Record<string, string> = {};
  const breakdown: Record<string, SlotRanking> = {};
  const notes: string[] = [];

  // Live mutable draft for within_repeat + pair_affinity awareness.
  const currentDraft = new Map<string, string>();

  // Seed currentDraft from already-filled slots so the scorer knows who's
  // taken and where they are (for pair affinity).
  for (const [slot, a] of Object.entries(assignments)) {
    const tmId = (a as any)?.tmId;
    if (tmId) currentDraft.set(slot, tmId);
  }

  const adjacency = scoringCtx.adjacency ?? buildDefaultAdjacency();

  for (const slotKey of orderedSlots) {
    // Preserve existing assignment if present.
    const existing = assignments[slotKey];
    if (existing?.tmId) {
      proposedAssignments[slotKey] = existing.tmId;
      breakdown[slotKey] = {
        topCandidates: [],
        pickedTmId: existing.tmId,
        preserved: true,
      };
      continue;
    }

    // Build candidate set: eligible + not yet placed this run.
    const usedIds = new Set(currentDraft.values());
    const candidates = roster.filter(
      (tm: any) =>
        !usedIds.has(tm.id) &&
        isEligibleForSlot(tm, slotKey)
    );

    // DEBUG — log details when candidates are unexpectedly empty
    if (candidates.length === 0) {
      const eligible = roster.filter((tm: any) => isEligibleForSlot(tm, slotKey));
      const notUsed = roster.filter((tm: any) => !usedIds.has(tm.id));
      console.warn(`[runWeightedPlanner] NO CANDIDATES for ${slotKey} — eligible=${eligible.length}  not-yet-used=${notUsed.length}  draft-size=${currentDraft.size}  roster=${roster.length}`);
      if (eligible.length > 0 && notUsed.length === 0) {
        console.warn(`  → ALL ${roster.length} TMs already placed. Used IDs:`, [...usedIds].join(", "));
      } else if (eligible.length === 0) {
        const sample = roster.slice(0, 3).map((tm: any) => `${tm.id}(pool=${tm.gravePool},gender=${tm.gender})`);
        console.warn(`  → None eligible for ${slotKey}. Sample TMs:`, sample.join(", "));
      }
      notes.push(`No eligible candidate found for ${slotKey}`);
      breakdown[slotKey] = {
        topCandidates: [],
        pickedTmId: null,
        preserved: false,
      };
      continue;
    }

    // Score each candidate.
    const ctx: ScoringContext = {
      ...scoringCtx,
      currentDraft,
      adjacency,
    };
    const scored = candidates
      .map((tm: any) => {
        const result = scoreAssignment(tm, slotKey, ctx);
        return {
          tmId: tm.id,
          tmName: tm.name || tm.fullName || tm.id,
          total: result.total,
          breakdown: result.breakdown,
          excluded: result.excluded,
          excludeReason: result.excludeReason,
        };
      })
      .sort((a, b) => {
        // Excluded candidates sink to the bottom.
        if (a.excluded && !b.excluded) return 1;
        if (!a.excluded && b.excluded) return -1;
        return b.total - a.total;
      });

    const top = scored.slice(0, topK);
    const picked = top.find((c) => !c.excluded);

    breakdown[slotKey] = {
      topCandidates: top,
      pickedTmId: picked ? picked.tmId : null,
      preserved: false,
    };

    if (picked) {
      proposedAssignments[slotKey] = picked.tmId;
      currentDraft.set(slotKey, picked.tmId);
    } else {
      notes.push(`No non-excluded candidate for ${slotKey}`);
    }
  }

  const usedIds = new Set(currentDraft.values());
  const unassignedPeople = roster.filter((tm: any) => !usedIds.has(tm.id));

  return { proposedAssignments, unassignedPeople, notes, breakdown };
}

export function isEligibleForSlot(tm: any, slotKey: string): boolean {
  const isGrave = !!tm.gravePool;
  const isAMOverlapAssigned = !!tm.isAMOverlap;
  const isPMOverlapAssigned = !!tm.isPMOverlap;

// …
  const gravePoolKind = String(tm.gravePool ?? "").toUpperCase();
  const isOverlapByPool = gravePoolKind === "AM" || gravePoolKind === "PM";
  const isFullGrave =
    isGrave && !isOverlapByPool && !isAMOverlapAssigned && !isPMOverlapAssigned;

  // Main Zone Deployment + Z9 Smoking Room — strict full-grave only
  if (slotKey.startsWith("Z")) {
    return isFullGrave;
  }

  // Overlap Tab AM — accept TMs flagged as AM by either signal
  if (slotKey.startsWith("OL-AM") || slotKey.includes("AM-Overlap")) {
    return isGrave && (isAMOverlapAssigned || gravePoolKind === "AM");
  }

  // Overlap Tab PM — accept TMs flagged as PM by either signal
  if (slotKey.startsWith("OL-PM") || slotKey.includes("PM-Overlap")) {
    return isGrave && (isPMOverlapAssigned || gravePoolKind === "PM");
  }

  // Men's Restrooms — full-night, male TMs only (null gender = eligible as safe fallback)
  if (slotKey.startsWith("MRR")) {
    if (isOverlapByPool || isAMOverlapAssigned || isPMOverlapAssigned) return false;
    const gender = String(tm.gender ?? "").toUpperCase();
    if (gender && gender !== "M") return false;
    return true;
  }

  // Women's Restrooms — full-night, female TMs only (null gender = eligible as safe fallback)
  if (slotKey.startsWith("WRR")) {
    if (isOverlapByPool || isAMOverlapAssigned || isPMOverlapAssigned) return false;
    const gender = String(tm.gender ?? "").toUpperCase();
    if (gender && gender !== "F") return false;
    return true;
  }

// …
  if (
    slotKey === "ADM" ||
    slotKey.startsWith("TR") ||
    slotKey.startsWith("AUX") ||
    slotKey.startsWith("SP")
  ) {
    // Exclude AM/PM overlap TMs — they cannot cover a full-night position
    if (isOverlapByPool || isAMOverlapAssigned || isPMOverlapAssigned) return false;
    return true;
  }

  return true;
}

// …

export function validatePlacementOrder(auxDefs: AuxDef[]): string[] {
  const warnings: string[] = [];
  const fixedSet = new Set(PLACEMENT_ORDER);

  const dynamicSlots = auxDefs
    .map((d) => d.key)
    .filter((key) => !fixedSet.has(key));

  if (dynamicSlots.length === 0) return warnings;

  // Check that all dynamic slots come after the last fixed slot in the order
  const lastFixedIndex = PLACEMENT_ORDER.length - 1;

  // For now we just warn if someone tries to insert a support slot in the middle
  // (future: we can enforce strict ordering when AUX is added)

  return warnings;
}

// …

export function getPlacementOrderText(): string {
  return `AUTHORITATIVE PLACEMENT ORDER (strict, non-negotiable for all auto-assignment and Grok suggestions):

1. Restrooms (Men’s + Women’s) — highest priority block
   MRR1, WRR1, MRR6, WRR6, MRR7, WRR7, MRR8, WRR8, MRR10, WRR10

2. Admin
   ADM

3–12. Main Zones (in this exact sequence)
   Z9, Z1, Z4, Z5, Z2, Z3, Z8, Z10, Z7, Z6

13. Zone 9 Smoking Room — FIXED POSITION (never conditional or moved)
    Z9SR

14–15. Trash
    TR1, TR2

16+. Any operator-added Overflow / Support slots (SP1, SP2, AUX..., etc.) come AFTER everything above.

When suggesting assignments, you MUST process and propose in this order. Never suggest filling a later slot (e.g. Z2 or Support) before all earlier slots in this list have been considered.`;
}

export function getEligibilityRulesText(): string {
  return `STRICT ELIGIBILITY RULES (Grok and all engines MUST obey):

- Main Zone Deployment slots (any slotKey starting with "Z", INCLUDING the fixed Z9SR) require a FULL-GRAVE team member. A TM is full-grave when ALL of the following hold: (a) gravePool is truthy, (b) gravePool is NOT the string "AM" or "PM" (those values mark the TM as an overlap-type employee, e.g. "Full" vs "AM" vs "PM"), AND (c) the per-night isAMOverlap and isPMOverlap flags are both false. Overlap TMs cover partial shifts (10pm–3am or 3am–7am) and cannot hold a zone for the full 11pm–7am window.
- AM Overlap slots (slotKeys starting with "OL-AM" or containing "AM-Overlap") require gravePool AND isAMOverlap.
- PM Overlap slots (slotKeys starting with "OL-PM" or containing "PM-Overlap") require gravePool AND isPMOverlap.
- Restrooms (MRR*/WRR*), ADM, Trash (TR*), and all Support/Overflow/AUX slots are full-night positions. Full-grave TMs are eligible. AM/PM overlap TMs (gravePool = "AM" or "PM", or isAMOverlap/isPMOverlap = true) are NOT eligible — they work partial shifts and cannot cover a full-night RR or Admin assignment. Non-grave active TMs are eligible for these slots.
- Breaks / break groups are IGNORED for all placement and suggestion decisions.
- Locked slots must be respected (do not suggest changes to locked assignments unless explicitly asked to propose unlocks).
- Always prefer minimal disruption and respect the current draft or live board state when provided.

These rules are non-negotiable. Any suggestion that would violate them must be rejected by the server guard before being shown to the operator.`;
}
