

import { supabase } from "../supabase";

// …

export interface EngineWeights {
  skill_match?: number;
  fatigue_index?: number;
  pair_affinity?: number;
  within_repeat?: number;
  area_diversity?: number;
  preference_fit?: number;
  soft_prefer_set?: number;
  cross_week_rotation?: number;
  weekly_load_balance?: number;
  prior_run_continuity?: number;
  skill_stretch_reward?: number;
  sweeper_rotation_penalty?: number;
}

export interface EngineThresholds {
  rotation_weeks?: number;
  fatigue_window_days?: number;
  override_load_threshold?: number;
  override_difficulty_threshold?: number;
}

export type PlacementMethod = "greedy" | "weighted" | "grok-hybrid";

export type GrokReasoningEffort = "none" | "low" | "medium" | "high";

export interface EngineConfig {
  id: string;
  isActive: boolean;
  weights: EngineWeights;
  thresholds: EngineThresholds;
  slotPriority: Record<string, number>; // slot → priority override
  placementMethod: PlacementMethod;
  
  grokReasoningEffort: GrokReasoningEffort;
  notes: string | null;
  createdAt: string;
  createdBy: string | null;
}

// …

export const DEFAULT_WEIGHTS: Required<EngineWeights> = {
  skill_match: 1.0,
  fatigue_index: 0.8,
  pair_affinity: 1.0,
  within_repeat: 1.0,
  area_diversity: 0.7,
  preference_fit: 1.5,
  soft_prefer_set: 0.6,
  cross_week_rotation: 0.5,
  weekly_load_balance: 0.5,
  prior_run_continuity: 0.4,
  skill_stretch_reward: 0.3,
  sweeper_rotation_penalty: 0.3,
};

export const DEFAULT_THRESHOLDS: Required<EngineThresholds> = {
  rotation_weeks: 8,
  fatigue_window_days: 7,
  override_load_threshold: 6.0,
  override_difficulty_threshold: 6.0,
};

export const DEFAULT_GROK_REASONING_EFFORT: GrokReasoningEffort = "medium";

export const FALLBACK_CONFIG: EngineConfig = {
  id: "fallback",
  isActive: true,
  weights: { ...DEFAULT_WEIGHTS },
  thresholds: { ...DEFAULT_THRESHOLDS },
  slotPriority: {},
  placementMethod: "weighted",
  grokReasoningEffort: DEFAULT_GROK_REASONING_EFFORT,
  notes: "Synthesized fallback — no active engine_config row found.",
  createdAt: new Date().toISOString(),
  createdBy: null,
};

export function resolvedWeights(cfg: EngineConfig): Required<EngineWeights> {
  return { ...DEFAULT_WEIGHTS, ...cfg.weights };
}

export function resolvedThresholds(cfg: EngineConfig): Required<EngineThresholds> {
  return { ...DEFAULT_THRESHOLDS, ...cfg.thresholds };
}

// …

export async function getActiveEngineConfig(): Promise<EngineConfig> {
  const { data, error } = await supabase
    .from("engine_config")
    .select(
      "id, is_active, weights, thresholds, slot_priority, placement_method, grok_reasoning_effort, notes, created_at, created_by"
    )
    .eq("is_active", true)
    .order("created_at", { ascending: false })
    .limit(1);

  if (error) {
    console.warn("[engineConfig] fetch failed, using fallback:", error.message);
    return FALLBACK_CONFIG;
  }

  if (!data || data.length === 0) {
    console.warn("[engineConfig] no active row found, using fallback");
    return FALLBACK_CONFIG;
  }

  const row = data[0] as any;
  const method = (row.placement_method ?? "weighted") as string;
  const reasoning = (row.grok_reasoning_effort ?? DEFAULT_GROK_REASONING_EFFORT) as string;
  const validReasoning: GrokReasoningEffort = (["none", "low", "medium", "high"].includes(reasoning)
    ? reasoning
    : DEFAULT_GROK_REASONING_EFFORT) as GrokReasoningEffort;

  return {
    id: row.id,
    isActive: !!row.is_active,
    weights: (row.weights ?? {}) as EngineWeights,
    thresholds: (row.thresholds ?? {}) as EngineThresholds,
    slotPriority: (row.slot_priority ?? {}) as Record<string, number>,
    placementMethod: (["greedy", "weighted", "grok-hybrid"].includes(method)
      ? method
      : "weighted") as PlacementMethod,
    grokReasoningEffort: validReasoning,
    notes: row.notes ?? null,
    createdAt: row.created_at,
    createdBy: row.created_by ?? null,
  };
}
