

import type {
  TMPreferenceRow,
  TMPairAffinityRow,
  TMAccommodationRow,
} from "./data";
import type { EngineConfig } from "./engineConfig";
import { resolvedWeights } from "./engineConfig";
// (uiToDb intentionally unused — slot_difficulty uses its own key scheme; see uiKeyToSlotDifficultyKey)

// …

export interface ScoringContext {
  
  config: EngineConfig;
  
  skillScores: Map<string, number>;
  
  slotDifficulty: Map<string, number>;
  
  preferencesByTm: Map<string, TMPreferenceRow[]>;
  
  pairAffinitiesByTm: Map<string, TMPairAffinityRow[]>;
  
  accommodationsByTm: Map<string, TMAccommodationRow[]>;
  
  currentDraft: Map<string, string>;
  
  adjacency: Map<string, string[]>;
}

export interface SignalScore {
  
  raw: number;
  
  weighted: number;
  
  note?: string;
}

export type SignalBreakdown = Record<string, SignalScore>;

export interface ScoreResult {
  
  total: number;
  
  breakdown: SignalBreakdown;
  
  excluded: boolean;
  
  excludeReason?: string;
}

// …

export function scoreAssignment(
  tm: any,
  slotKey: string,
  ctx: ScoringContext
): ScoreResult {
  const breakdown: SignalBreakdown = {};
  let excluded = false;
  let excludeReason: string | undefined;

  // ---- within_repeat (hard) -----------------------------------------
  // If this TM is already proposed in another slot this run, exclude.
  for (const [otherSlot, tmId] of ctx.currentDraft) {
    if (otherSlot !== slotKey && tmId === tm.id) {
      excluded = true;
      excludeReason = `Already placed in ${otherSlot} this draft`;
      breakdown.within_repeat = {
        raw: -1,
        weighted: -Infinity,
        note: excludeReason,
      };
      break;
    }
  }

  if (!excluded) {
    breakdown.within_repeat = { raw: 0, weighted: 0 };
  }

  // ---- skill_match --------------------------------------------------
  const skill = scoreSkillMatch(tm, slotKey, ctx);
  breakdown.skill_match = skill;

  // ---- preference_fit (hard preferences) ---------------------------
  const prefHard = scorePreference(tm, slotKey, ctx, "hard");
  breakdown.preference_fit = prefHard;

  // ---- soft_prefer_set ----------------------------------------------
  const prefSoft = scorePreference(tm, slotKey, ctx, "soft");
  breakdown.soft_prefer_set = prefSoft;

  // Hard "avoid" preference becomes a hard exclude.
  if (!excluded && prefHard.raw <= -1) {
    excluded = true;
    excludeReason = "Hard-avoid preference for this slot";
  }

  // ---- pair_affinity ------------------------------------------------
  const pair = scorePairAffinity(tm, slotKey, ctx);
  breakdown.pair_affinity = pair;

  // Hard pair-avoid becomes a hard exclude.
  if (!excluded && pair.raw <= -1 && pair.note?.includes("hard")) {
    excluded = true;
    excludeReason = pair.note;
  }

  // ---- Sum --------------------------------------------------------
  let total = 0;
  for (const k of Object.keys(breakdown)) {
    const w = breakdown[k].weighted;
    if (Number.isFinite(w)) total += w;
  }

  if (excluded) total = -Infinity;

  return { total, breakdown, excluded, excludeReason };
}

// …

function scoreSkillMatch(
  tm: any,
  slotKey: string,
  ctx: ScoringContext
): SignalScore {
  const weights = resolvedWeights(ctx.config);
  const tmSkill = ctx.skillScores.get(tm.id);
  const slotDifficultyKey = uiKeyToSlotDifficultyKey(slotKey);
  const slotDiff = slotDifficultyKey ? ctx.slotDifficulty.get(slotDifficultyKey) : undefined;

  if (tmSkill === undefined || slotDiff === undefined) {
    return {
      raw: 0,
      weighted: 0,
      note:
        tmSkill === undefined
          ? "no skill_score on file"
          : "no slot_difficulty on file",
    };
  }

// …
  const distance = Math.abs(tmSkill - slotDiff);
  let raw = 1 - distance / 5; // 5 = half of 10, so distance 5 → raw 0
  if (tmSkill >= slotDiff) raw = Math.max(raw, 0.2); // floor when overqualified
  raw = Math.max(-1, Math.min(1, raw));

  return {
    raw,
    weighted: raw * weights.skill_match,
    note: `skill ${tmSkill} vs difficulty ${slotDiff}`,
  };
}

function scorePreference(
  tm: any,
  slotKey: string,
  ctx: ScoringContext,
  strength: "hard" | "soft"
): SignalScore {
  const weights = resolvedWeights(ctx.config);
  const rows = ctx.preferencesByTm.get(tm.id) ?? [];
// …
  const matches = rows.filter((r) => {
    if (r.strength !== strength) return false;
    if (!r.target) return false;
    return (
      r.target === slotKey ||
      slotKey.startsWith(r.target) ||
      r.target.toLowerCase() === slotKey.toLowerCase()
    );
  });

  if (matches.length === 0) {
    return { raw: 0, weighted: 0 };
  }

  // Treat multiple matches as a sum; prefer +1, avoid -1.
  let raw = 0;
  matches.forEach((m) => {
    if (m.stance === "prefer") raw += 1;
    else if (m.stance === "avoid") raw -= 1;
  });
  raw = Math.max(-1, Math.min(1, raw));

  const weight = strength === "hard" ? weights.preference_fit : weights.soft_prefer_set;
  return {
    raw,
    weighted: raw * weight,
    note: matches
      .map((m) => `${strength} ${m.stance} ${m.target}`)
      .join(", "),
  };
}

function scorePairAffinity(
  tm: any,
  slotKey: string,
  ctx: ScoringContext
): SignalScore {
  const weights = resolvedWeights(ctx.config);
  const rows = ctx.pairAffinitiesByTm.get(tm.id) ?? [];
  if (rows.length === 0) return { raw: 0, weighted: 0 };

  // Find the neighbors (already placed) we have affinity rows for.
  const neighbors = ctx.adjacency.get(slotKey) ?? [];
  const neighborTmIds = neighbors
    .map((n) => ctx.currentDraft.get(n))
    .filter((id): id is string => !!id);

  if (neighborTmIds.length === 0) return { raw: 0, weighted: 0 };

  let raw = 0;
  const notes: string[] = [];
  rows.forEach((r) => {
    const partnerId = r.withTmId;
    if (!partnerId) return;
    if (!neighborTmIds.includes(partnerId)) return;
    const sign = r.stance === "prefer" ? 1 : r.stance === "avoid" ? -1 : 0;
    const mag = r.strength === "hard" ? 1 : 0.5;
    raw += sign * mag;
    notes.push(`${r.stance}/${r.strength} with ${partnerId}`);
  });

  raw = Math.max(-1, Math.min(1, raw));
  return {
    raw,
    weighted: raw * weights.pair_affinity,
    note: notes.length > 0 ? notes.join(", ") : undefined,
  };
}

// …

function uiKeyToSlotDifficultyKey(slotKey: string): string | null {
  if (slotKey === "Z9SR") return "Zone9SR";
  if (slotKey === "ADM") return "Admin";
  if (slotKey === "TR1") return "Trash1";
  if (slotKey === "TR2") return "Trash2";
  const zoneMatch = slotKey.match(/^Z(\d+)$/);
  if (zoneMatch) return `Zone${zoneMatch[1]}`;
  if (/^[MW]RR\d+$/.test(slotKey)) return slotKey; // MRR1, WRR10, etc. — identical
  if (/^SP\d+$/.test(slotKey)) return null; // not in slot_difficulty (yet)
  if (/^AUX\d*$/.test(slotKey)) return null;
  if (/^OL-(AM|PM)-\d+$/.test(slotKey)) return null;
  return null;
}

export function buildDefaultAdjacency(): Map<string, string[]> {
  const out = new Map<string, string[]>();
  const setBoth = (a: string, b: string) => {
    if (!out.has(a)) out.set(a, []);
    if (!out.has(b)) out.set(b, []);
    out.get(a)!.push(b);
    out.get(b)!.push(a);
  };

  // Zone-to-zone linear adjacency
  for (let i = 1; i < 10; i++) {
    setBoth(`Z${i}`, `Z${i + 1}`);
  }

// …
  const rrBlocks: Array<[number, string[]]> = [
    [1, ["Z1", "Z2"]],
    [6, ["Z6"]],
    [7, ["Z7"]],
    [8, ["Z8"]],
    [10, ["Z10"]],
  ];
  rrBlocks.forEach(([num, zones]) => {
    zones.forEach((z) => {
      setBoth(`MRR${num}`, z);
      setBoth(`WRR${num}`, z);
    });
    setBoth(`MRR${num}`, `WRR${num}`);
  });

  return out;
}
