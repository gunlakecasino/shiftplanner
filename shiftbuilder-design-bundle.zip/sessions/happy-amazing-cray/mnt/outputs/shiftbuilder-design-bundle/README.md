# ShiftBuilder — Design Bundle

GLCR Grave Shift scheduling app built with Next.js 16 / React 19 / Tailwind 4 / Supabase.

## Directory Map

```
app/
  globals.css                        — Print CSS, artboard dimensions (1056×816px landscape), dark mode
  shiftbuilder/
    ShiftBuilderClient.tsx           — ROOT component (~5700 lines). All state, handlers, render tree
    CommandPalette.tsx               — cmdk-based command palette overlay
    page.tsx                         — Next.js route entry
    actions.ts                       — Server actions (Grok AI streaming)
    GOLDEN_VISUAL_SPEC.md            — Visual design spec / Golden reference doc
    components/
      ZoneCard.tsx                   — Zone assignment card (Z1–Z10)
      RRCard.tsx                     — Restroom card (Men's / Women's split)
      AuxCard.tsx                    — Auxiliary slot card (Z9SR, Admin, Trash, Support)
      AssignmentLine.tsx             — TM name chip inside a card
      BreakBadge.tsx                 — Break group badge (1/2/3/–)
      CoverageBar.tsx                — Coverage % bar across zones
      OverlapSlot.tsx                — PM/AM overlap task slot
      TaskRow.tsx                    — Shift task row
      ZoneTaskList.tsx               — Task list inside a zone
      PrintCommandCenter.tsx         — Full-screen print config overlay (drag-to-reorder, presets, cover page, overview)
    sudo/
      SudoWindow.tsx                 — Admin control window frame
      DefaultsTab.tsx / TeamTab.tsx / SchedulesTab.tsx / TasksTab.tsx
      BatchPlannerTab.tsx / ReportsTab.tsx / EngineConfigTab.tsx
    xai/
      XAISphere.tsx                  — Grok AI sphere widget
    hooks/
      useTheme.ts / useToast.ts / useZoom.ts / useRosterPanels.ts

lib/shiftbuilder/
  constants.ts      — ZONE_DEFS, RR_DEFS, AUX_DEFS, all color palettes, icons
  dateUtils.ts      — DayDef, SHIFT_DAY_COLORS, buildDayDefs, date helpers
  slot-keys.ts      — UI key ↔ DB key translation (Z1↔zone_1, MRR1↔rr_1_2+mens, etc.)
  data.ts           — All Supabase queries (ZoneAssignmentRow, TeamMember, getNightAssignments…)
  placement.ts      — Auto-placement engine (score-based TM→slot matching)
  scoring.ts        — TM scoring signals (history, gender, section, skill)
  engineConfig.ts   — Placement engine config / weight tuning
  grokEngine.ts     — Grok AI override pipeline
  grokSchemas.ts    — Zod schemas for AI responses
  useCommandActions.tsx  — Command palette action registry
  useShiftHistory.ts     — Undo/redo history stack
  useSlotDnd.ts          — dnd-kit drag-and-drop
  usePencilHover.ts      — Hover pencil edit affordance
  spotlightMove.ts       — Spotlight zone-move logic
```

## Key Concepts

- **Artboard**: 1056×816px (11×8.5" landscape @ 96dpi). Class `.print-artboard` — WYSIWYG print.
- **Views**: `deployment` (zone cards grid) | `breaks` (wave break schedule) | `tasks` (shift tasks)
- **Slot keys**: UI = `Z1`…`Z10`, `MRR1`/`WRR1`, `Z9SR`, `ADM`, `TR1`, `TR2`, `SP1`, `SP2`
- **Day colors**: `SHIFT_DAY_COLORS = ["#C13A14","#0065bf","#4d1a8a","#1f7a3d","#b8860b","#8b4513","#2f4f4f"]` (Fri→Thu)
- **Print pipeline**: `handlePrintWithConfig(config)` — captures live artboard HTML per day via flushSync, assembles pages, injects `@page` margin override, calls `window.print()`
- **Draft Mode**: changes staged in local state, applied to Supabase on commit
- **Grok Intelligence**: optional AI placement suggestions via xAI API

## Stack
- Next.js 16.2 · React 19 · TypeScript 5 · Tailwind 4
- Supabase (Postgres + Realtime)
- dnd-kit (drag-and-drop)
- cmdk (command palette)
- lucide-react (icons)
- GSAP (XAI sphere animation)
