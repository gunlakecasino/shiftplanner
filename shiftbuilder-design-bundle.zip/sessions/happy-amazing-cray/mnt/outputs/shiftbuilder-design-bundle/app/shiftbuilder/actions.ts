"use server";

import {
  callGrok,
  buildShiftBuilderSystemPrompt,
  buildGrokIntelligenceSystemPrompt,
  parseGrokStructuredResponse,
  guardGrokActions,
  type GrokMessage,
  type GrokBoardSnapshot,
  type GrokStructuredResponse,
  type ReasoningEffort,
} from "@/lib/xai";

// Vercel AI SDK (Phase 3 migration) — structured output + official xAI provider
import { generateObject } from "ai";
import {
  createGrokEngineModel,
  createGrokSuggestionModel,
} from "@/lib/shiftbuilder/grokClient";
import {
  GrokEngineResponseSchema,
  GrokStructuredResponseSchema,
} from "@/lib/shiftbuilder/grokSchemas";

import type { GrokReasoningEffort } from "@/lib/shiftbuilder/engineConfig";
import type { TeamMember } from "@/lib/shiftbuilder/data";
import {
  buildGrokEngineSystemPrompt,
  parseGrokEngineResponse,
  guardGrokEnginePicks,
  type GrokEngineSnapshot,
  type GrokEnginePick,
} from "@/lib/shiftbuilder/grokEngine";

export type GrokContext = {
  type: "slot" | "person";
  slotKey?: string;
  personName?: string;
  currentAssignment?: string;
  rosterSummary?: string;
};

export async function askGrokForShiftSuggestions(context: GrokContext): Promise<string> {
  const systemPrompt = buildShiftBuilderSystemPrompt();

  let userPrompt = "";

  if (context.type === "slot" && context.slotKey) {
    userPrompt = `The operator just tapped slot "${context.slotKey}" in the ShiftBuilder.

Current occupant: ${context.currentAssignment || "empty"}

Give me 3 strong, practical suggestions for who should be assigned here (or why it should stay empty). 
Consider GRAVE eligibility, current coverage, and break fairness.

Be specific and actionable.`;
  } else if (context.type === "person" && context.personName) {
    userPrompt = `The operator is looking at team member "${context.personName}".

${context.currentAssignment ? `They are currently on: ${context.currentAssignment}` : "They are currently unassigned."}

Give me smart suggestions for what we should do with this person right now (best slots, break timing, swaps, etc.).`;
  } else {
    userPrompt = "Give general high-value suggestions for improving tonight's GRAVE coverage.";
  }

  const messages: GrokMessage[] = [
    { role: "system", content: systemPrompt },
    { role: "user", content: userPrompt },
  ];

  try {
    const result = await callGrok(messages, {
      model: "grok-4.3",
      reasoningEffort: "low", // fast interactive suggestions from Command Palette
      temperature: 0.6,
      maxTokens: 600,
    });

    return result;
  } catch (error) {
    console.error("Grok call failed:", error);
    return "Sorry, I couldn't reach Grok right now. Please try again in a moment.";
  }
}

// …

export type RichGrokRequest = {
  snapshot: GrokBoardSnapshot;
  
  userQuestion?: string;
  
  rosterForGuard: TeamMember[];
};

export async function askGrokForStructuredSuggestions(
  request: RichGrokRequest
): Promise<{
  text: string;
  structured?: GrokStructuredResponse;
  warnings: string[];
  usedStructured: boolean;
}> {
  const { snapshot, userQuestion, rosterForGuard } = request;

  const systemPrompt = buildGrokIntelligenceSystemPrompt(snapshot);

  const focus = userQuestion
    ? `\n\nOperator focus: ${userQuestion}`
    : snapshot.selectedSlotKey
    ? `\n\nThe operator tapped slot "${snapshot.selectedSlotKey}" and wants the best legal suggestions for it.`
    : snapshot.selectedPersonName
    ? `\n\nThe operator is looking at "${snapshot.selectedPersonName}" and wants smart things to do with them right now.`
    : "\n\nGive the operator the highest-value improvements possible for tonight's GRAVE sheet.";

  const userPrompt = `Here is the complete current board snapshot and rules.

${focus}

Remember the output contract: first a single clean JSON block with "explanation" + "actions", then any extra prose.`;

  const messages: GrokMessage[] = [
    { role: "system", content: systemPrompt },
    { role: "user", content: userPrompt },
  ];

  try {
    const model = createGrokSuggestionModel();

    // Use the official Vercel AI SDK structured output.
    // This gives us a validated, typed object instead of fragile regex parsing.
    const { object: parsed } = await generateObject({
      model,
      schema: GrokStructuredResponseSchema,
      messages,
      temperature: 0.5,
      maxTokens: 900,
      providerOptions: {
        xai: {
          reasoningEffort: "low", // fast & responsive for interactive palette use
        },
      },
    });

    let finalStructured: GrokStructuredResponse | undefined;
    let warnings: string[] = [];

    if (parsed) {
      // Run the authoritative guard (this is what would have prevented the May 21 screenshot disasters)
      const guardResult = guardGrokActions(
        parsed.actions,
        rosterForGuard,
        snapshot.currentAssignments
      );

      finalStructured = {
        explanation: parsed.explanation,
        actions: guardResult.validActions,
      };
      warnings = guardResult.warnings;
    }

    // For the `text` field (shown in the palette), return a clean JSON representation.
    // This is more reliable than the old raw model text.
    const textForUI = JSON.stringify(parsed, null, 2);

    return {
      text: textForUI,
      structured: finalStructured,
      warnings,
      usedStructured: !!finalStructured,
    };
  } catch (error) {
    console.error("Grok structured call failed:", error);
    return {
      text: "Sorry, I couldn't reach Grok right now. Please try again in a moment.",
      warnings: ["Grok call failed"],
      usedStructured: false,
    };
  }
}

// …

export type GrokEngineRunResult = {
  picks: GrokEnginePick[];
  explanation: string;
  warnings: string[];
  usedGrok: boolean;
  rawText: string;
};

export async function askGrokEngineDraft(
  snapshot: GrokEngineSnapshot
): Promise<GrokEngineRunResult> {
  const systemPrompt = buildGrokEngineSystemPrompt(snapshot);
  const userPrompt = `Here is tonight's snapshot and per-slot ranking.

Choose final picks per slot. Prefer the deterministic top candidate unless
context (notes, call-offs, recent history, pair affinity with already-placed
neighbors) suggests overriding. Output the JSON block exactly as specified
in the system prompt.`;

  const messages: GrokMessage[] = [
    { role: "system", content: systemPrompt },
    { role: "user", content: userPrompt },
  ];

  try {
    // Effort comes live from the SUDO > Engine Config tab via the DB
    const effort = snapshot.grokReasoningEffort ?? "medium";

    const model = createGrokEngineModel();

    const { object: parsed } = await generateObject({
      model,
      schema: GrokEngineResponseSchema,
      messages,
      temperature: 0.2,
      maxTokens: 1500,
      // Reasoning effort is passed via providerOptions at call time (the official way)
      providerOptions: {
        xai: {
          reasoningEffort: effort,
        },
      },
    });

    const guard = guardGrokEnginePicks(parsed.picks, snapshot);

    // For debugging / "Why?" panel we store the structured result as JSON.
    // (In a follow-up we can also capture the original text via response if needed.)
    const rawTextForDebug = JSON.stringify(parsed, null, 2);

    return {
      picks: guard.validPicks,
      explanation: parsed.explanation,
      warnings: guard.warnings,
      usedGrok: guard.validPicks.length > 0,
      rawText: rawTextForDebug,
    };
  } catch (err) {
    console.error("[actions] askGrokEngineDraft failed:", err);
    return {
      picks: [],
      explanation: "",
      warnings: [`Grok engine call failed: ${err instanceof Error ? err.message : String(err)}`],
      usedGrok: false,
      rawText: "",
    };
  }
}
